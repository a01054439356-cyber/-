# 머스닥 (MUKSDAQ)
소비자 수요 ↔ 점주 혜택 제안 외식 플랫폼. HTML/CSS/JS만 사용(빌드 없음) → GitHub Pages로 바로 배포 가능.

## 폴더 구조 (파일 단위로 담당자 분배)
```
index.html            로그인 + 소비자/점주 선택
home.html             공통 홈 (역할별 시작 화면 안내)
profile.html          공통 내 프로필 / 로그아웃
assets/style.css      공통 디자인 (색상 변수 :root 수정)
assets/common.js      로그인 상태·상단바·하단탭·샘플데이터
user/   market · demand-new · demand-done · offers · offer-detail
owner/  dashboard · offer-new · offer-sent · reservations · report
```
## 화면 흐름
- 소비자: 로그인 → 시장(market) → 수요 등록 → 등록 완료 → 받은 제안 → 제안 상세/예약 → 시장
- 점주: 로그인 → 대시보드 → 제안 등록 → 발송 확인 → 예약/문의 관리 → 분석 리포트
## 작업 규칙
1. 내 화면 HTML 안의 `<main>` 내용만 수정. 2. 공통 색/버튼은 style.css 클래스(.card .btn .chip .tag) 재사용.
3. 새 화면은 기존 파일을 복사해 `MK.init()` 줄을 유지하고, 메뉴 추가는 common.js의 `tabs`에 한 줄.
