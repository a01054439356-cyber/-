/* 공통 스크립트: 로그인 상태, 상단바, 하단 탭, 샘플 데이터. 각 페이지는 MK.init() 한 줄만 호출 */
const ICON={receipt:'<rect x="5" y="3" width="14" height="18" rx="2"/><path d="M9 8h6M9 12h6M9 16h4"/>',search:'<circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/>',bookmark:'<path d="M6 3h12v18l-6-4-6 4z"/>',home:'<path d="M3 11l9-8 9 8v10h-6v-6H9v6H3z"/>',plus:'<circle cx="12" cy="12" r="9"/><path d="M12 8v8M8 12h8"/>',inbox:'<path d="M3 13l3-8h12l3 8v6H3z"/><path d="M3 13h5l1 3h6l1-3h5"/>',cal:'<rect x="3" y="5" width="18" height="16" rx="3"/><path d="M3 10h18M8 3v4M16 3v4"/>',chart:'<path d="M4 20V10M10 20V4M16 20v-8M22 20H2"/>',store:'<path d="M4 9l2-5h12l2 5M4 9h16v11H4zM9 20v-6h6v6"/>',wallet:'<path d="M3 7a2 2 0 0 1 2-2h13v4"/><rect x="3" y="7" width="18" height="13" rx="2"/><path d="M16 13.5h2"/>',user:'<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-6 8-6s8 2 8 6"/>'};
const MK={
  /* ---- 주문/계좌 공통 로직 (order.html, account.html 이 함께 사용) ---- */
  START_PTS:1000000, BASE:{'고기':{q:10,avg:8000}},   // 샘플: 시작 포인트와 처음 보유 종목
  price:c=>MK.data.cats.find(x=>x.n===c).v,            // 종목 현재가 (서버 연동 시 교체)
  orders(){try{return JSON.parse(localStorage.getItem('mk_ord'))||[]}catch(e){return[]}},
  saveOrders(o){try{localStorage.setItem('mk_ord',JSON.stringify(o))}catch(e){}},
  acct(){ // 주문 내역(st: done 체결 / open 미체결 / cancel 취소)으로 계좌를 계산
    const pos={},resQ={};let cash=MK.START_PTS,resP=0,buy=0,sell=0;
    for(const c in MK.BASE){pos[c]={...MK.BASE[c]};buy+=MK.BASE[c].q*MK.BASE[c].avg}
    MK.orders().slice().reverse().forEach(o=>{
      if(o.st==='open'){if(o.side==='buy')resP+=o.p*o.q;else resQ[o.c]=(resQ[o.c]||0)+o.q}
      else if(o.st==='done'){const x=pos[o.c]||(pos[o.c]={q:0,avg:0});
        if(o.side==='buy'){x.avg=(x.avg*x.q+o.p*o.q)/(x.q+o.q);x.q+=o.q;cash-=o.p*o.q;buy+=o.p*o.q}
        else{x.q-=o.q;cash+=o.p*o.q;sell+=o.p*o.q}}});
    return {cash,avail:cash-resP,pos,resQ,buy,sell}},
  col:x=>x>=0?'var(--up)':'var(--dn)',tri:x=>x>=0?'▲':'▼',
  esc:s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c])),
  favs(){try{return JSON.parse(localStorage.getItem('mk_favs'))||['고기','초밥','분식']}catch(e){return['고기','초밥','분식']}},
  role:()=>localStorage.getItem('mk_role'),
  photo(){try{return localStorage.getItem('mk_photo')||''}catch(e){return''}},
  nick(){try{return localStorage.getItem('mk_nick')||MK.userId()}catch(e){return MK.userId()}},   // 닉네임(마이페이지 표시 이름): 없으면 아이디
  userId(){try{return localStorage.getItem('mk_uid')||'머스닥 사용자'}catch(e){return'머스닥 사용자'}},
  badge(){   // 하단바 '주문 내역' 숫자: 결제 전 예약 수 (결제 완료·예약 취소 시 줄어듦)
    let n=0;try{n=(JSON.parse(localStorage.getItem('mk_res'))||[]).filter(r=>!r.paid).length}catch(e){}
    document.querySelectorAll('nav.tabs a[href$="user/orders.html"]').forEach(a=>{let b=a.querySelector('.bdg');
      if(!n){if(b)b.remove();return}if(!b){b=document.createElement('i');b.className='bdg';a.append(b)}b.textContent=n>99?'99+':n})},
  tabs:{
    user:[['user/market.html','홈','home'],['user/orders.html','주문 내역','receipt'],['user/demand-index.html','수요지수','chart'],['user/pay.html','먹스닥pay','wallet'],['user/mypage.html','마이페이지','user']],
    owner:[['owner/dashboard.html','대시보드','home'],['owner/offer-new.html','제안 등록','plus'],['owner/reservations.html','예약','cal'],['owner/report.html','리포트','chart'],['profile.html','프로필','user']]
  },
  // 샘플 데이터 (나중에 서버 연동 시 이 부분만 교체)
  data:{
    // 매장 (이름, 업종, 평점, 후기 수, 거리km, 혜택 [할인문구, 할인율, 추가혜택], 연관 음식 종목, 간판색, 이모티콘)
    stores:[{n:'먹스닥 한식당',k:'한식',r:4.8,rv:1203,d:1.2,b:['전체 메뉴 20% 할인',20,'사이드 1개 무료'],c:['고기'],bg:'#5a3a22',e:'🍲'},
      {n:'스시정',k:'일식',r:4.9,rv:634,d:1.8,b:['세트메뉴 15% 할인',15,'음료 1잔 무료'],c:['초밥'],bg:'#2b2b33',e:'🍣'},
      {n:'스테이크하우스',k:'양식',r:4.7,rv:892,d:2.3,b:['전 메뉴 10% 할인',10,'디저트 서비스'],c:['고기','파스타'],bg:'#23282f',e:'🥩'},
      {n:'성건동 분식',k:'분식',r:4.6,rv:421,d:0.9,b:['2인 세트 3,000원 할인',8,'음료 1+1'],c:['분식'],bg:'#d4542a',e:'🍢'},
      {n:'바플치킨',k:'치킨',r:4.8,rv:971,d:2.7,b:['치킨 전 메뉴 15% 할인',15,'감자튀김 무료'],c:['치킨'],bg:'#2d2d2d',e:'🍗'},
      {n:'라멘야',k:'일식',r:4.6,rv:509,d:3.1,b:['라멘 세트 10% 할인',10,'교자 1개 무료'],c:['마라탕'],bg:'#4a2a1c',e:'🍜'},
      {n:'안나푸르나',k:'아시안',r:4.7,rv:88,d:1.5,b:['커리 세트 10% 할인',10,'난 1장 무료'],c:['커리'],bg:'#b5651d',e:'🍛'}],   // 임시 테스트 매장(영수증 인증 확인용)
    // 카테고리: 이름, 현재 수요, 어제 대비(%), 최근 추이, 평점
    cats:[{n:'고기',v:8421,p:23,s:[3,4,4,6,8],r:4.6},{n:'치킨',v:6732,p:18,s:[4,4,5,5,7],r:4.4},{n:'초밥',v:5981,p:42,s:[2,3,3,5,8],r:4.8},
          {n:'마라탕',v:4211,p:-7,s:[6,6,5,5,4],r:4.2},{n:'파스타',v:3980,p:6,s:[4,4,3,4,5],r:4.5},{n:'분식',v:2710,p:-12,s:[7,6,5,4,3],r:4.1}],
    index:'12,843',rank:[['고기',8421,'+23%'],['치킨',6732,'+18%'],['초밥',5981,'+42%'],['마라탕',4211,'-7%'],['파스타',3980,'+6%']],
    offers:[['안나푸르나','1.5km','커리 세트 10% 할인','커리 세트 주문 시 난 1장 무료','2인 이상'],['옥화식당','420m','5,000원 할인','삼겹살 3인분 + 된장찌개 + 음료','46,000원'],['고기곰는날','730m','계란찜 무료','고기 주문 시 계란찜 서비스','2인 이상'],['대학고깃집','280m','웨이팅 없이 바로 입장','지금 방문 시 대기 없이 입장','바로 입장']],
    reservations:[['김민수 외 3명','19:00 · 4명','10% 할인 제안'],['이지은 외 1명','20:00 · 2명','사이드 메뉴 제안'],['박준호 외 2명','19:30 · 3명','즉시 입장 제안']]
  },
  /* opts: {back:true, public:true(로그인 불필요), role:'user'|'owner'(해당 역할만 접근)} */
  init(o={}){
    const root=document.body.dataset.root||'',r=MK.role();
    if(!o.public&&!r){location.replace(root+'index.html');return}
    if(o.role&&r!==o.role){location.replace(root+'home.html');return}
    const top=document.createElement('header');top.className='top';
    top.innerHTML=(o.back?'<a href="javascript:history.back()" aria-label="뒤로">←</a>':'')+
      `${o.title?`<b class="ptitle">${o.title}</b>`:`<a class="logo" href="${root}${r==='owner'?'owner/dashboard':'user/market'}.html">${o.logoImg!==false?`<img src="${root}assets/logo.png" alt="머스닥" height="26" style="display:block;height:26px;width:auto">`:'MUKS<b>DAQ</b>'}</a>`}${o.bell?`<span class="hr"><a class="bell" href="${root}user/notifications.html" aria-label="알림"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10 21h4"/></svg>${localStorage.getItem('mk_read')?'':'<i></i>'}</a>${o.menu?`<button class="mbtn" id="mkMenu" aria-label="전체 메뉴" aria-haspopup="dialog"><img src="${root}assets/menu.png" alt=""></button>`:''}</span>`:`<span class="sub">${r==='owner'?'점주':r==='user'?'소비자':''}</span>`}`;
    document.body.prepend(top);
    if(o.clear){top.classList.add('clear');const f=()=>top.classList.toggle('solid',scrollY>8);addEventListener('scroll',f,{passive:true});f()}   // 맨 위에서는 투명, 스크롤하면 흰색
    if(r){const here=location.pathname.split('/').slice(-2).join('/');
      const nav=document.createElement('nav');nav.className='tabs';
      nav.innerHTML=MK.tabs[r].map(([p,t,i])=>`<a href="${root}${p}" class="${here.endsWith(p)?'on':''}"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${ICON[i]}</svg><span>${t}</span></a>`).join('');
      document.body.append(nav);if(o.glass)nav.classList.add('glass');MK.badge()}
    if(o.menu)MK.drawer(root);
  },
  /* 전체 메뉴: 오른쪽에서 열리는 세로 팝업. 카테고리별 바로가기는 아래 G 목록만 고치세요 */
  drawer(root){
    const G=[['매장 · 혜택',[['📋','조건등록','user/demand-new.html'],['🏪','매장 추천 결과','user/stores.html'],['🎁','혜택 매장','user/offers.html'],['🔖','저장한 매장','user/saved.html']]],
      ['음식 주식',[['📊','수요지수','user/demand-index.html'],['🧾','체결내역','user/history.html']]],
      ['관심',[['❤️','관심 종목','user/favorites.html']]],
      ['내 정보',[['🔔','알림','user/notifications.html'],['💳','먹스닥pay','user/pay.html'],['👤','마이페이지','user/mypage.html']]]];
    const d=document.createElement('div');d.className='dm';d.setAttribute('role','dialog');d.setAttribute('aria-label','전체 메뉴');
    d.innerHTML=`<div class="bg"></div><div class="in"><aside class="pn"><div class="row" style="margin-bottom:6px"><b style="font-size:20px">전체 메뉴</b><button class="chip" data-x aria-label="닫기">✕</button></div>`+
      G.map(([t,L])=>`<h3>${t}</h3><div class="mg">${L.map(([e,n,p])=>`<a class="mi" href="${root}${p}"><span>${e}</span>${n}</a>`).join('')}</div>`).join('')+
      `<button class="mi out" data-out>🚪 로그아웃</button></aside></div>`;
    document.body.append(d);
    const btn=document.getElementById('mkMenu'),set=v=>{d.classList.toggle('open',v);btn.setAttribute('aria-expanded',v)};
    btn.onclick=()=>set(true);d.querySelector('.bg').onclick=()=>set(false);d.querySelector('[data-x]').onclick=()=>set(false);
    d.querySelector('[data-out]').onclick=MK.logout;document.addEventListener('keydown',e=>{if(e.key==='Escape')set(false)})},
  // 칩 선택: <div class="chips" data-single> 안의 .chip 클릭 시 선택 표시
  chips(){document.querySelectorAll('.chips').forEach(g=>g.addEventListener('click',e=>{
    const c=e.target.closest('.chip');if(!c)return;
    if(g.hasAttribute('data-single'))g.querySelectorAll('.chip').forEach(x=>x.classList.remove('on'));
    c.classList.toggle('on')}))},
  saved(){try{return JSON.parse(localStorage.getItem('mk_saved'))||[]}catch(e){return[]}},
  toggleSaved(n){let a=MK.saved();a=a.includes(n)?a.filter(x=>x!==n):[...a,n];try{localStorage.setItem('mk_saved',JSON.stringify(a))}catch(e){}return a.includes(n)},
  /* 매장 카드 한 개의 HTML (stores / search / saved 페이지 공용) */
  /* 매장 사진(자동): assets/stores/ 폴더에 '매장이름.jpg'(png·webp·jpeg도 가능) 파일을 넣으면 자동으로 나옵니다. 파일이 없으면 이모지가 나와요. */
  pic(s){const r=document.body.dataset.root||'';return `<img class="pic" src="${r}assets/stores/${encodeURIComponent(s.n)}.jpg" data-r="${r}" data-n="${encodeURIComponent(s.n)}" data-e="${MK.esc(s.e||'🍽️')}" data-x="0" alt="" onerror="MK.picErr(this)">`},
  picErr(i){const X=['png','webp','jpeg'],k=+i.dataset.x;if(k<X.length){i.dataset.x=k+1;i.src=`${i.dataset.r}assets/stores/${i.dataset.n}.${X[k]}`}else i.replaceWith(document.createTextNode(i.dataset.e))},
  storeCard(s){const on=MK.saved().includes(s.n);
    return `<div class="stc" data-go="${MK.esc(s.n)}"><div class="stimg" style="background:${s.bg}"><small>${MK.esc(s.n)}</small><span>${MK.pic(s)}</span></div><div class="stbody"><div class="row" style="align-items:flex-start"><b class="stn">${MK.esc(s.n)}</b><button class="bm${on?' on':''}" data-bm="${MK.esc(s.n)}" aria-label="저장">${on?'★':'☆'}</button></div><div class="sub" style="margin:2px 0 8px"><span style="color:#ffb300">★</span> <b style="color:var(--text)">${s.r}</b> (${s.rv.toLocaleString()}) · ${s.d}km</div><div class="pills"><span class="pill o">％ ${MK.esc(s.b[0])}</span><span class="pill">🎁 ${MK.esc(s.b[2])}</span></div></div></div>`},
  bindSaved(el,after){el.addEventListener('click',e=>{const b=e.target.closest('[data-bm]');
    if(b){const on=MK.toggleSaved(b.dataset.bm);b.classList.toggle('on',on);b.textContent=on?'★':'☆';if(after)after();return}
    const c=e.target.closest('[data-go]');if(c)location.href='store.html?n='+encodeURIComponent(c.dataset.go)})},   // 카드를 누르면 매장 상세로
  store(n){return MK.data.stores.find(x=>x.n===n)||MK.data.stores[0]},
  // 매장 상세 정보 (영업시간, 주소, 전화, 대표 메뉴, 혜택 조건, 후기) — 서버 연동 시 교체
  info:{
    '먹스닥 한식당':{h:'11:00 ~ 22:00 (라스트오더 21:00)',a:'경주시 성건동 123-4',t:'054-111-1001',m:[['한식 정식',12000],['불고기 전골',18000],['된장찌개',8000]],u:'예약 시 자동 적용 · 1일 1회',rv:[['김*수',5,'정갈하고 맛있어요. 사이드 서비스가 좋았어요!'],['이*은',5,'가족 외식하기 딱 좋아요.']]},
    '스시정':{h:'11:30 ~ 21:30 (브레이크 15:00~17:00)',a:'경주시 황오동 55-2',t:'054-111-1002',m:[['모둠초밥 12p',24000],['연어 덮밥',15000],['우동',7000]],u:'세트메뉴 주문 시 적용 · 예약 필수',rv:[['박*호',5,'신선하고 가성비 최고예요.'],['최*현',5,'음료 서비스까지 받았어요.']]},
    '스테이크하우스':{h:'11:30 ~ 22:00',a:'경주시 동천동 88-1',t:'054-111-1003',m:[['안심 스테이크',32000],['리브아이 스테이크',38000],['까르보나라',15000]],u:'전 메뉴 10% 할인 · 주류 제외',rv:[['정*아',5,'고기 굽기가 딱 좋아요.'],['한*우',4,'디저트가 맛있었어요.']]},
    '성건동 분식':{h:'10:00 ~ 21:00',a:'경주시 성건동 12-7',t:'054-111-1004',m:[['떡볶이',5000],['모둠 튀김',6000],['김밥',3500]],u:'2인 세트 주문 시 적용 · 매장 식사만',rv:[['송*민',5,'가까워서 자주 가요. 음료 1+1이 좋아요.'],['오*진',4,'양이 푸짐해요.']]},
    '바플치킨':{h:'15:00 ~ 24:00',a:'경주시 용강동 301-5',t:'054-111-1005',m:[['후라이드',18000],['양념치킨',19000],['감자튀김',5000]],u:'치킨 전 메뉴 · 포장 불가',rv:[['윤*서',5,'바삭하고 맛있어요!'],['강*훈',5,'감자튀김 무료라 좋아요.']]},
    '안나푸르나':{h:'11:00 ~ 22:00',a:'경주시 황성동 20-3',t:'054-111-1007',m:[['치킨 마살라 커리',13000],['탄두리 치킨',16000],['갈릭 난',3000]],u:'커리 세트 주문 시 적용',rv:[['문*영',5,'커리가 진하고 난이 쫄깃해요.']]},
    '라멘야':{h:'11:00 ~ 21:00 (브레이크 15:00~16:30)',a:'경주시 선도동 76-9',t:'054-111-1006',m:[['돈코츠 라멘',9500],['쇼유 라멘',9000],['교자 5p',5000]],u:'라멘 세트 주문 시 적용',rv:[['임*라',5,'국물이 진해요.'],['조*빈',4,'교자도 맛있어요.']]}},
  logout(){localStorage.removeItem('mk_role');location.href=(document.body.dataset.root||'')+'index.html'}
};
