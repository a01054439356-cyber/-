/* 외부 서비스 설정. 네이버 지도를 쓰려면 NAVER_KEY 에 네이버 클라우드 플랫폼(console.ncloud.com)에서 발급받은 Maps(Web Dynamic Map) 클라이언트 ID를 넣으세요.
   발급 시 '서비스 URL'에 이 사이트 주소(예: http://127.0.0.1:5500, 배포 도메인)를 등록해야 지도가 나옵니다. 비워 두면 기본 지도 이미지가 표시됩니다. */
window.MK_CONFIG={NAVER_KEY:''};
