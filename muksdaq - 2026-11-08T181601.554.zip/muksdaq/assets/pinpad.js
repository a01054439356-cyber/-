/* 결제 비밀번호 입력 패드 (6자리). 화면용: 해시는 간단한 방식이라 실제 서비스에서는 서버에서 처리해야 해요. */
window.MKPin={
  LEN:6,
  hash(p){let h=2166136261;const s='mk-pay:'+p;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619)}return String(h>>>0)},
  has(){try{return !!localStorage.getItem('mk_paypin')}catch(e){return false}},
  check(p){try{return localStorage.getItem('mk_paypin')===MKPin.hash(p)}catch(e){return false}},
  save(p){try{localStorage.setItem('mk_paypin',MKPin.hash(p))}catch(e){}},
  weak(p){return /^(\d)\1+$/.test(p)||'0123456789'.includes(p)||'9876543210'.includes(p)},
  /* el 안에 점 6개 + 숫자패드를 그리고, 6자리가 채워지면 onDone(pin)을 불러요 */
  mount(el,onDone){
    el.innerHTML='<div class="pp-dots">'+'<i></i>'.repeat(6)+'</div><div class="pp-msg" aria-live="polite"></div><div class="pp-pad">'+
      [1,2,3,4,5,6,7,8,9,'',0,'⌫'].map(k=>k===''?'<span></span>':`<button type="button" data-k="${k}">${k}</button>`).join('')+'</div>';
    let v='';const dots=[...el.querySelectorAll('.pp-dots i')],msg=el.querySelector('.pp-msg');
    const paint=()=>dots.forEach((d,i)=>d.classList.toggle('on',i<v.length));
    const push=k=>{if(k==='⌫'){v=v.slice(0,-1);paint();return}if(v.length>=6)return;v+=k;paint();if(v.length===6){const p=v;setTimeout(()=>onDone(p),120)}};
    el.querySelector('.pp-pad').onclick=e=>{const b=e.target.closest('button');if(b)push(b.dataset.k)};
    const key=e=>{if(!el.offsetParent)return;if(/^\d$/.test(e.key))push(e.key);else if(e.key==='Backspace')push('⌫')};
    document.addEventListener('keydown',key);
    return{reset(){v='';paint()},msg(t,bad){msg.textContent=t||'';msg.className='pp-msg'+(bad?' bad':'')},
      shake(){const d=el.querySelector('.pp-dots');d.classList.remove('sk');void d.offsetWidth;d.classList.add('sk')},destroy(){document.removeEventListener('keydown',key)}}
  }
};
