/* 영수증 인증: ① 이미지 품질검사 → ② 글자 인식(OCR) → ③ 가맹점 정보 대조
   MK.receipt.verify(file, 매장이름) → Promise<{ok, reasons[], data:{name,amount,date,phone}, quality}>
   OCR 은 Tesseract.js(브라우저에서 동작, 인터넷 필요)를 처음 필요할 때 불러옵니다.
   서버가 생기면 ocr() 함수만 서버 호출로 바꾸면 됩니다. */
MK.receipt=(()=>{
  const TH={minLong:600,minShort:380,brightMin:45,brightMax:252,contrastMin:22,sharpMin:35};   // 품질 기준값 (필요하면 여기만 조정)
  const loadImg=file=>new Promise((res,rej)=>{const u=URL.createObjectURL(file),im=new Image();im.onload=()=>res({im,u});im.onerror=()=>rej(new Error('img'));im.src=u});
  /* ① 품질검사: 해상도 · 밝기 · 대비 · 선명도(라플라시안 분산) */
  function quality(im){
    const W0=im.naturalWidth,H0=im.naturalHeight,long=Math.max(W0,H0),short=Math.min(W0,H0),fails=[];
    if(long<TH.minLong||short<TH.minShort)fails.push('사진 해상도가 너무 낮아요');
    const k=Math.min(1,700/long),w=Math.max(8,Math.round(W0*k)),h=Math.max(8,Math.round(H0*k)),c=document.createElement('canvas');c.width=w;c.height=h;
    const x=c.getContext('2d',{willReadFrequently:true});x.drawImage(im,0,0,w,h);const d=x.getImageData(0,0,w,h).data,g=new Float32Array(w*h);
    let sum=0;for(let i=0;i<w*h;i++){g[i]=.299*d[i*4]+.587*d[i*4+1]+.114*d[i*4+2];sum+=g[i]}
    const mean=sum/(w*h);let v=0;for(let i=0;i<w*h;i++)v+=(g[i]-mean)**2;const sd=Math.sqrt(v/(w*h));
    let lv=0,ln=0,ls=0;for(let yy=1;yy<h-1;yy++)for(let xx=1;xx<w-1;xx++){const i=yy*w+xx,l=4*g[i]-g[i-1]-g[i+1]-g[i-w]-g[i+w];ls+=l;lv+=l*l;ln++}
    const sharp=lv/ln-(ls/ln)**2;
    if(mean<TH.brightMin)fails.push('사진이 너무 어두워요');else if(mean>TH.brightMax)fails.push('사진이 너무 밝아요');
    if(sd<TH.contrastMin)fails.push('글자가 구분되지 않아요');
    if(sharp<TH.sharpMin)fails.push('사진이 흐려요');
    return {ok:!fails.length,fails,w:W0,h:H0,mean:Math.round(mean),contrast:Math.round(sd),sharp:Math.round(sharp)}}
  /* ② OCR (한글+영문) */
  let eng=null;
  const loadLib=()=>window.Tesseract?Promise.resolve():new Promise((res,rej)=>{const s=document.createElement('script');s.src='https://cdnjs.cloudflare.com/ajax/libs/tesseract.js/5.1.1/tesseract.min.js';s.onload=res;s.onerror=()=>rej(new Error('lib'));document.head.append(s)});
  async function ocr(file){await loadLib();eng=eng||await Tesseract.createWorker('kor+eng');
    const r=await Promise.race([eng.recognize(file),new Promise((_,j)=>setTimeout(()=>j(new Error('timeout')),90000))]);return r.data.text||''}
  /* 영수증 글자에서 정보 뽑기 */
  function parse(t){
    const T=t.replace(/[Oo](?=\d)/g,'0'),flat=t.replace(/\s+/g,'').toLowerCase(),out={flat,name:'',amount:0,date:null,phone:''};
    let m=T.match(/(합\s*계|총\s*액|결제\s*금액|받을\s*금액|청구\s*금액|승인\s*금액|total)[^\d]{0,14}([\d,.]{4,})/i);
    if(m)out.amount=+m[2].replace(/\D/g,'');
    if(!out.amount){const all=(T.match(/\d{1,3}(?:,\d{3})+/g)||[]).map(x=>+x.replace(/,/g,''));out.amount=all.length?Math.max(...all):0}
    m=T.match(/(20\d{2})\s*[.\-\/년]\s*(\d{1,2})\s*[.\-\/월]\s*(\d{1,2})/);if(m)out.date=new Date(+m[1],+m[2]-1,+m[3]);
    m=T.match(/(0\d{1,2})[-\s.]?(\d{3,4})[-\s.]?(\d{4})/);if(m)out.phone=m[1]+m[2]+m[3];
    return out}
  /* ③ 가맹점 대조: 상호명 · 전화번호 · 주소 중 하나라도 일치 */
  function match(p,store){const info=MK.info[store]||{},nm=store.replace(/\s+/g,'').toLowerCase(),tel=(info.t||'').replace(/\D/g,''),
      addr=((info.a||'').match(/([가-힣]+[동리읍면로길])\s*([\d-]+)/)||[]),a2=addr.length?(addr[1]+addr[2]).toLowerCase():'';
    const by=[];if(p.flat.includes(nm))by.push('상호명');if(tel&&p.phone===tel)by.push('전화번호');if(a2&&p.flat.includes(a2))by.push('주소');return by}
  async function verify(file,store){
    const reasons=[],res={ok:false,reasons,data:{},quality:null};
    let L;try{L=await loadImg(file)}catch(e){reasons.push('이미지를 읽을 수 없어요');return res}
    res.quality=quality(L.im);URL.revokeObjectURL(L.u);
    if(!res.quality.ok){reasons.push(...res.quality.fails);return res}
    let text;try{text=await ocr(file)}catch(e){reasons.push(e.message==='timeout'?'영수증 인식 시간이 초과됐어요':'영수증 인식 엔진을 불러오지 못했어요 (인터넷 연결을 확인해 주세요)');return res}
    const p=parse(text);res.data={amount:p.amount,date:p.date,phone:p.phone,text};
    const by=match(p,store);res.data.matched=by;
    if(!by.length)reasons.push('영수증의 가맹점 정보가 이 매장과 일치하지 않아요');
    if(!(p.amount>0))reasons.push('영수증에서 결제 금액을 찾지 못했어요');
    if(p.date&&p.date>new Date())reasons.push('영수증 날짜가 올바르지 않아요');
    res.ok=!reasons.length;return res}
  return {verify,quality,parse,match,TH}
})();
