/* 공통 스크립트: 로그인 상태, 상단바, 하단 탭, 샘플 데이터. 각 페이지는 MK.init() 한 줄만 호출 */
const MK={
  role:()=>localStorage.getItem('mk_role'),
  tabs:{
    user:[['user/market.html','시장'],['user/demand-new.html','수요 등록'],['user/offers.html','받은 제안'],['profile.html','내 프로필']],
    owner:[['owner/dashboard.html','대시보드'],['owner/offer-new.html','제안 등록'],['owner/reservations.html','예약'],['owner/report.html','리포트'],['profile.html','프로필']]
  },
  // 샘플 데이터 (나중에 서버 연동 시 이 부분만 교체)
  data:{
    index:'12,843',rank:[['고기',8421,'+23%'],['치킨',6732,'+18%'],['초밥',5981,'+42%'],['마라탕',4211,'-7%'],['파스타',3980,'+6%']],
    offers:[['옥화식당','420m','5,000원 할인','삼겹살 3인분 + 된장찌개 + 음료','46,000원'],['고기곰는날','730m','계란찜 무료','고기 주문 시 계란찜 서비스','2인 이상'],['대학고깃집','280m','웨이팅 없이 바로 입장','지금 방문 시 대기 없이 입장','바로 입장']],
    reservations:[['김민수 외 3명','19:00 · 4명','10% 할인 제안'],['이지은 외 1명','20:00 · 2명','사이드 메뉴 제안'],['박준호 외 2명','19:30 · 3명','즉시 입장 제안']]
  },
  /* opts: {back:true, public:true(로그인 불필요), role:'user'|'owner'(해당 역할만 접근)} */
  init(o={}){
    const root=document.body.dataset.root||'',r=MK.role();
    if(!o.public&&!r){location.replace(root+'index.html');return}
    if(o.role&&r!==o.role){location.replace(root+'home.html');return}
    const top=document.createElement('header');top.className='top';
    top.innerHTML=(o.back?'<a href="javascript:history.back()" aria-label="뒤로">←</a>':'')+
      `<a class="logo" href="${root}home.html">MUKS<b>DAQ</b></a><span class="sub">${r==='owner'?'점주':r==='user'?'소비자':''}</span>`;
    document.body.prepend(top);
    if(r){const here=location.pathname.split('/').slice(-2).join('/');
      const nav=document.createElement('nav');nav.className='tabs';
      nav.innerHTML=MK.tabs[r].map(([p,t])=>`<a href="${root}${p}" class="${here.endsWith(p)?'on':''}">${t}</a>`).join('');
      document.body.append(nav)}
  },
  // 칩 선택: <div class="chips" data-single> 안의 .chip 클릭 시 선택 표시
  chips(){document.querySelectorAll('.chips').forEach(g=>g.addEventListener('click',e=>{
    const c=e.target.closest('.chip');if(!c)return;
    if(g.hasAttribute('data-single'))g.querySelectorAll('.chip').forEach(x=>x.classList.remove('on'));
    c.classList.toggle('on')}))},
  logout(){localStorage.removeItem('mk_role');location.href=(document.body.dataset.root||'')+'index.html'}
};
